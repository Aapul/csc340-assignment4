package com.csc340.jpademo.tasks;

import com.csc340.jpademo.constants.Status;
import com.csc340.jpademo.goals.Goals;
import jakarta.annotation.Nonnull;
import jakarta.persistence.*;

@Entity
@Table(name = "tasks")
public class Tasks {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int taskId;

    @ManyToOne
    @JoinColumn(name = "goalId")
    private Goals goals;

    @Nonnull
    private String title;

    private String details;

    @Nonnull
    private Status status;

    public Tasks() {
    }

    public Tasks(int taskId, Goals goals, @Nonnull String title, String details, @Nonnull Status status) {
        this.taskId = taskId;
        this.goals = goals;
        this.title = title;
        this.details = details;
        this.status = status;
    }

    public Tasks(Tasks tasks, Goals goals) {
        this.taskId = tasks.getTaskId();
        this.goals = goals;
        this.title = tasks.getTitle();
        this.details = tasks.getDetails();
        this.status = tasks.getStatus();
    }

    public Tasks(@Nonnull String title, String details, @Nonnull Goals goals) {
        this.goals = goals;
        this.title = title;
        this.details = details;
        this.status = Status.PENDING;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public Goals getGoals() {
        return goals;
    }

    public void setGoals(Goals goals) {
        this.goals = goals;
    }

    @Nonnull
    public String getTitle() {
        return title;
    }

    public void setTitle(@Nonnull String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    @Nonnull
    public Status getStatus() {
        return status;
    }

    public void setStatus(@Nonnull Status status) {
        this.status = status;
    }
}

