package com.csc340.jpademo.constants;

public enum Status {
    PENDING,
    INPROGRESS,
    DONE,
    CANCELLED
}
