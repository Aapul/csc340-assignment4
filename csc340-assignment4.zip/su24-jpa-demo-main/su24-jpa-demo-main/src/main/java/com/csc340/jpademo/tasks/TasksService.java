package com.csc340.jpademo.tasks;

import com.csc340.jpademo.goals.Goals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TasksService {

    @Autowired
    TasksRepository tasksRepository;

    public void createNewTask(Tasks tasks, Goals goals) {
        tasks = new Tasks(tasks.getTitle(), tasks.getDetails(), goals);
        tasksRepository.save(tasks);
    }

    public void updateTasks(Tasks tasks, Goals goals) {
        tasks = new Tasks(tasks, goals);
        tasksRepository.save(tasks);
    }

    public List<Tasks> getAllTasksByGoalId(int goalId) {
        return tasksRepository.getTasksByGoalId(goalId);
    }

    public Tasks getTasksByGoalId(int goalId) {
        return tasksRepository.findById(goalId).orElse(null);
    }

    public void deleteTasksByGoalId(int goalId) {
        tasksRepository.deleteById(goalId);
    }

    public void deleteAllTasksByGoalId(int goalId) {
        List<Tasks> tasks = tasksRepository.getTasksByGoalId(goalId);
        tasksRepository.deleteAll(tasks);
    }
}