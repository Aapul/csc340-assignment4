package com.csc340.jpademo.goals;

import com.csc340.jpademo.constants.Status;
import jakarta.persistence.Entity;
import jakarta.annotation.Nonnull;
import jakarta.persistence.*;
import org.springframework.lang.NonNull;

import java.util.Date;

@Entity
@Table(name = "goals")
public class Goals {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int goalId;

    private int userId;

    @Nonnull
    private String title;

    private String details;

    private Date targetDate;

    private Status status;

    public Goals() {
    }

    public Goals(int goalId, int userId, String title, String details, Date targetDate, Status status) {
        this.goalId = goalId;
        this.userId = userId;
        this.title = title;
        this.details = details;
        this.targetDate = targetDate;
        this.status = status;
    }
    public Goals(@NonNull String title, String details, @NonNull java.sql.Date targetDate) {
        this.userId = 1;
        this.title = title;
        this.details = details;
        this.targetDate = targetDate;
        this.status = Status.PENDING;
    }

    public Goals(Goals goals) {
        this.goalId = goals.getGoalId();
        this.userId = goals.getUserId();
        this.title = goals.getTitle();
        this.details = goals.getDetails();
        this.targetDate = goals.getTargetDate();
        this.status = goals.getStatus();
    }

    public int getGoalId() {
        return goalId;
    }

    public void setGoalId(int id) {
        this.goalId = goalId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(String name) {
        this.userId = userId;
    }

    public String getTitle() { return title;}

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Date getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(Date targetDate) {
        this.targetDate = targetDate;
    }

    @NonNull
    public Status getStatus() {
        return status;
    }

    public void setStatus(@NonNull Status status) {
        this.status = status;
    }

}
