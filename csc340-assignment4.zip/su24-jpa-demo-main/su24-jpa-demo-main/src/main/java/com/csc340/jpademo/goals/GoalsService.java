package com.csc340.jpademo.goals;

import com.csc340.jpademo.tasks.TasksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;


@Service
public class GoalsService {

    @Autowired
    GoalsRepository goalsRepository;

    @Autowired
    TasksService tasksService;

    public void createNewGoal(Goals goals) {
        if (goalsRepository.existsById(goals.getGoalId())) {
            goals = new Goals(goals);
            goalsRepository.save(goals);
            return;
        }
        goals = new Goals(goals.getTitle(), goals.getDetails(), (Date) goals.getTargetDate());
        goalsRepository.save(goals);
    }

    public void deleteGoal(int id) {
        tasksService.deleteTasksByGoalId(id);
        goalsRepository.deleteById(id);
    }

    public Object getAllUserGoals() {
        // Using a static userId since we are the only user
        return goalsRepository.getUserGoals(1);
    }

    public Goals getGoalById(int id) {
        return goalsRepository.findById(id).orElse(null);
    }
}
