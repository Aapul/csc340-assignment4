package com.csc340.jpademo.goals;

import com.csc340.jpademo.tasks.TasksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/goals")
public class GoalsController {

    @Autowired
    GoalsService goalsService;

    @Autowired
    TasksService tasksService;

    @GetMapping("/all")
    public String getAllGoals(Model model) {
        model.addAttribute("goalList", goalsService.getAllUserGoals());
        return "goal-list";
    }

    @GetMapping("/{id}")
    public String getGoalById(@PathVariable int id, Model model) {
        model.addAttribute("goal", goalsService.getGoalById(id));
        model.addAttribute("taskList", tasksService.getAllTasksByGoalId(id));
        return "goal-detail";
    }

    @PostMapping("/create")
    public String createGoal(@ModelAttribute("goal") Goals goal) {
        goalsService.createNewGoal(goal);
        return "redirect:/goals/all";
    }

    @PostMapping("/update")
    public String updateGoal(Goals goals) {
        goalsService.createNewGoal(goals);
        return "redirect:" + goals.getGoalId();
    }

    @GetMapping("/update/{id}")
    public String showUpdateForm(@PathVariable int id, Model model) {
        model.addAttribute("goal", goalsService.getGoalById(id));
        return "goal-update";
    }

    @GetMapping("/delete/{id}")
    public String deleteGoalById(@PathVariable int id) {
        goalsService.deleteGoal(id);
        return "redirect:/goals/all";
    }
}
