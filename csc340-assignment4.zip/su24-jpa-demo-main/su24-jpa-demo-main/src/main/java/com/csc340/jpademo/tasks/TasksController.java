package com.csc340.jpademo.tasks;

import com.csc340.jpademo.goals.Goals;
import com.csc340.jpademo.goals.GoalsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tasks")
public class TasksController {

    @Autowired
    TasksService tasksService;

    @Autowired
    GoalsService goalsService;


    @PostMapping("/create/{id}")
    public String showTaskForm(@ModelAttribute("task") Tasks tasks, @PathVariable int id) {
        Goals goals = goalsService.getGoalById(id);
        tasksService.createNewTask(tasks, goals);
        return "redirect:/goals/" + id;

    }


    @PostMapping("/update")
    public String updateGoals(@RequestParam(value = "goalId", required = true) int goalId, Tasks tasks) {
        tasksService.updateTasks(tasks, goalsService.getGoalById(goalId));
        return "redirect:" + tasks.getTaskId();
    }

    @GetMapping("/update/{taskId}")
    public String showUpdateForm(@PathVariable int taskId, Model model) {
        model.addAttribute("task", tasksService.getTasksByGoalId(taskId));
        return "task-update";
    }


    @GetMapping("/delete/{id}")
    public String deleteTasks(@PathVariable int id) {
        int goalId = tasksService.getTasksByGoalId(id).getGoals().getGoalId();
        tasksService.deleteTasksByGoalId(id);
        return "redirect:/goals/" + goalId;
    }

    @GetMapping("/{id}")
    public Object getTasks(@PathVariable int id, Model model) {
        model.addAttribute("tasks", tasksService.getTasksByGoalId(id));
        return "tasks-detail";
    }
}